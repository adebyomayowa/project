<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/admit-form.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:37 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AKKHOR | Admission Form</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="css/all.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Select 2 CSS -->
    <link rel="stylesheet" href="css/select2.min.css">
    <!-- Date Picker CSS -->
    <link rel="stylesheet" href="css/datepicker.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize js -->
    <script src="js/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
        <!-- Header Menu Area Start Here -->
      <?php 
        include 'header.php'
      ?>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
            <?php include 'sidenav.php'?>
            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Students</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Student Admit Form</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Admit Form Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Add New Students</h3>
                            </div>
                            <div class="dropdown">
                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                                    aria-expanded="false">...</a>

                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-times text-orange-red"></i>Close</a>
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                </div>
                            </div>
                        </div>
                        <form class="new-added-form" method="POST" action="admit-form.php" enctype="multipart/form-data">
                            <div class="row">
                            <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Surname *</label>
                                    <input type="text" name="surname" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>First Name *</label>
                                    <input type="text" name="firstname" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Last Name *</label>
                                    <input type="text" name="lastname" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Gender *</label>
                                    <select class="select2" name="gender">
                                        <option>Male</option>
                                        <option>Female</option>
                                     
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Age*</label>
                                    <input type="text" placeholder="" name="age" class="form-control"
                                        data-position='bottom right'>
                                    <i class="far fa-age"></i>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Blood Group *</label>
                                    <select class="select2" name="blood">
                                        <option >A+</option>
                                        <option >A-</option>
                                        <option >B+</option>
                                        <option >B-</option>
                                        <option >O+</option>
                                        <option >O-</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Religion *</label>
                                    <select class="select2" name="religion">
                                        <option>Islam</option>
                                        <option>Christian</option>
                                        <option>Others</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Class *</label>
                                    <select class="select2" name="class">
                                        <option >PlayGroup</option>
                                        <option >KG 1</option>
                                        <option >KG 2</option>
                                        <option >Nursery 1</option>
                                        <option >Nursery 2</option>
                                        <option >Primary One</option>
                                        <option >Primary Two</option>
                                        <option >Primary Three</option>
                                        <option >Primary Four</option>
                                        <option >Primary Five</option>
                                        <option >Primary Six</option>

                                    </select>
                                </div>
                                
                            </div>
                            <div class="row" style="margin-top:30px;font-weight:bold;">
                            <div class="col-xl-3 col-lg-6 col-12 form-group" style="margin-top:30px;">
                                    <label>Guardian's Details *</label>
                            </div>
                                
                            </div>
                            <div class="row">
                            <div class="col-xl-3 col-lg-6 col-12 form-group" style="margin-top:30px;">
                                    <label>Parent name</label>
                                    <input type="text" name="parentname" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group" style="margin-top:30px;">
                                    <label>E-Mail</label>
                                    <input type="email" name="email" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group" style="margin-top:30px;">
                                    <label>Phone</label>
                                    <input type="text" name="phone" placeholder="" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group" style="margin-top:30px;">
                                    <label>Address</label>
                                    <input type="text" name="address" placeholder="" class="form-control">
                                </div>
                                <div class="col-lg-6 col-12 form-group mg-t-30">
                                    <label class="text-dark-medium">Upload Student Photo (150px X 150px)</label>
                                    <input type="file" name="image" class="form-control-file">
                                </div>
                                <?php $regno= 'KKS'.$rand=rand(10000000,99999999); ?>
                                <div class="col-12 form-group mg-t-8">
                                    <input type="submit" name="register" value="Save" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Reset</button>
                                </div>
                            </div>
                            <?php


                            if (isset($_POST['register']))
                            {
                            require 'conn.php';
                            echo $surname=$_POST['surname'];
                            echo $firstname=$_POST['firstname'];
                            echo $lastname=$_POST['lastname'];
                            echo $age=$_POST['age'];
                            echo $gender=$_POST['gender'];
                            echo $blood=$_POST['blood'];
                            echo $religion=$_POST['religion'];
                            echo $class=$_POST['class'];
                            echo $regno;
                            echo $parentname=$_POST['parentname'];
                            echo $email=$_POST['email'];
                            echo $phone=$_POST['phone'];
                            echo $address=$_POST['address'];
                            

                            $image = $_FILES['image']['name'];
                            // Get text
                            // $image_text = mysqli_real_escape_string($conn, $_POST['image_text']);
          
                            // image file directory
                            $target = "student_image/".basename($image);
                            $direct="./student_image/".$image;
                            // execute query
          
          
                            if (move_uploaded_file($_FILES['image']['tmp_name'], $target))
                             {
                              $msg = "Image uploaded successfully";
                            }else
                            {
                              $msg = "Failed to upload image";
                            }
                          


                            if (!empty($surname) && !empty($firstname) && !empty($lastname) && !empty($age) && !empty($gender) && !empty($blood) && !empty($religion) && !empty($class) && !empty($regno) && !empty($parentname) && !empty($email) && !empty($phone) && !empty($address) )

                            {
                                $insert="INSERT INTO student (id,surname,firstname,lastname,gender,age,blood,religion,class,regno,parentname,email,phone,address,myfile,date)  VALUES (null,'$surname','$firstname','$lastname','$gender','$age','$blood','$religion','$class','$regno','$parentname','$email','$phone','$address','$direct',null)";

                                $query=mysqli_query($conn,$insert);

                             if ($query)
                             {
                                echo '<script>alert("Students successfully registered");</script>';

                             }
                             else 
                             {
                                echo mysqli_error($query);
                             }
                            }
                            else
                            {
                                echo '<script>alert("Fields cannot be blank");</script>';
                            }
                            }
                            ?>
                        </form>
                    </div>
                </div>
                <!-- Admit Form Area End Here -->
              <?php include 'footer.php' ?>
            </div>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Select 2 Js -->
    <script src="js/select2.min.js"></script>
    <!-- Date Picker Js -->
    <script src="js/datepicker.min.js"></script>
    <!-- Scroll Up Js -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/admit-form.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:38 GMT -->
</html>