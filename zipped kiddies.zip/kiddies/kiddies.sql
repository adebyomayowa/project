-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2019 at 12:01 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kiddies`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `surname` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `gender` text NOT NULL,
  `age` text NOT NULL,
  `blood` text NOT NULL,
  `religion` text NOT NULL,
  `class` text NOT NULL,
  `regno` text NOT NULL,
  `parentname` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `address` text NOT NULL,
  `myfile` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `surname`, `firstname`, `lastname`, `gender`, `age`, `blood`, `religion`, `class`, `regno`, `parentname`, `email`, `phone`, `address`, `myfile`, `date`) VALUES
(1, 'Adebayo', 'Mayowa', 'Temitope', '19', '0', 'A+', 'Christian', 'Primary Six', 'KKS58560848', 'Mr Adebayo', 'mayowatope119@gmail.com', '08085590183', '19, kajola street sabo ojodu berger lagos', './student_image/IMG_20190110_151128.jpg', '2019-07-05 15:46:27'),
(2, 'Adebayo', 'Mayowa', 'Temitope', '19', 'Male', 'A+', 'Christian', 'Primary Six', 'KKS94808060', 'Mr Adebayo', 'mayowatope119@gmail.com', '08085590183', '19, kajola street sabo ojodu berger lagos', './student_image/IMG_20190110_151128.jpg', '2019-07-05 15:48:01'),
(3, 'temitope', 'mayowatope', 'temi', 'Male', '29', 'A+', 'Islam', 'PlayGroup', 'KKS96510045', 'Mr Adebayo', 'mayowatope119@gmail.com', '08085590183', '19, kajola street sabo ojodu berger lagos', './student_image/IMG_20190428_121818.jpg', '2019-07-05 15:49:37');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `class` text NOT NULL,
  `teacher` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `title`, `class`, `teacher`) VALUES
(1, 'English language', 'Nursery 1', 'belo kola'),
(2, 'mathematics', 'Primary Two', 'Adebayo Mayowa'),
(3, 'mathematics', 'Primary Two', 'Adebayo Mayowa');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `surname` text NOT NULL,
  `firstname` text NOT NULL,
  `qualification` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `regno` text NOT NULL,
  `phone` text NOT NULL,
  `gender` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `surname`, `firstname`, `qualification`, `email`, `address`, `regno`, `phone`, `gender`, `image`, `date`) VALUES
(1, 'Adebayo', 'Mayowa', 'OND', 'mayowatope119@gmail.com', '19, kajola street sabo ojodu berger lagos', 'KKT30705555', '08085590183', 'Male', './teacher_image/IMG_20190428_120453.jpg', '2019-07-05 17:15:43'),
(2, 'belo', 'kola', 'HND', 'mayowatope119@gmail.comm', '19, kajola street sabo ojodu berger lagos', 'KKT51237839', '08085590183', 'Female', './teacher_image/7.PNG', '2019-07-06 18:07:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
