
<center>
<footer class="footer-wrap-layout1">
                    <div class="copyright"><a href="https://capriquotatechnologies.com">Developed by CAPRIQUOTA Technologies</a> © Copyrights 2019.<br> All rights reserved.  </div>
                </footer>
                </center>
                <!-- Footer Area End Here -->';