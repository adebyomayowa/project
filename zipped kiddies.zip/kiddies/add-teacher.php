<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/add-teacher.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:39 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AKKHOR | Add Teacher</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="css/all.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Select 2 CSS -->
    <link rel="stylesheet" href="css/select2.min.css">
    <!-- Date Picker CSS -->
    <link rel="stylesheet" href="css/datepicker.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize js -->
    <script src="js/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
         <!-- Header Menu Area Start Here -->
        <?php 

        include 'header.php'
        ?>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
    <?php
    include 'sidenav.php'
    ?>
            
            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Teacher</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Add New Teacher</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add New Teacher Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Add New Teacher</h3>
                            </div>
                           <div class="dropdown">
                                <a class="dropdown-toggle" href="#" role="button" 
                                data-toggle="dropdown" aria-expanded="false">...</a>
        
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Close</a>
                                    <a class="dropdown-item" href="#"><i class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                    <a class="dropdown-item" href="#"><i class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                </div>
                            </div>
                        </div>
                        <form class="new-added-form" method="POST" action="add-teacher.php"  enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Surname *</label>
                                    <input type="text" placeholder="" name="surname"class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Firstname *</label>
                                    <input type="text" placeholder="" name="firstname" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Gender *</label>
                                    <select class="select2" name="gender">
                                        <option >Male</option>
                                        <option >Female</option>
                                      
                                    </select>
                                </div>
                               
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Qualification *</label>
                                    <select class="select2" name="qualification">
                                        <option >OND</option>
                                        <option >HND</option>
                                        <option >B.Sc</option>
                                        <option >B Tech</option>
                                        <option >NCE</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>E-Mail</label>
                                    <input type="email" placeholder="" name="email" class="form-control">
                                </div>
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Address</label>
                                    <input type="text" placeholder="" name="address" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Phone</label>
                                    <input type="text" placeholder="" name="phone" class="form-control">
                                </div>
                                <div class="col-lg-6 col-12 form-group mg-t-30">
                                    <label class="text-dark-medium">Upload Student Photo (150px X 150px)</label>
                                    <input type="file" name="image" class="form-control-file">
                                </div>
                                <div class="col-12 form-group mg-t-8">
                                    <input type="submit" name="register" value="Register" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Reset</button>
                                </div>
                            </div>
                            <?php
                            require 'conn.php';
                            $regno= 'KKT'.$rand=rand(10000000,99999999);
                            
                          
                          if (isset($_POST['register']))
                          {


                            @ $image = $_FILES['image']['name'];
                            // Get text
                            // $image_text = mysqli_real_escape_string($conn, $_POST['image_text']);
          
                            // image file directory
                            $target = "teacher_image/".basename($image);
                            $direct="./teacher_image/".$image;
                            // execute query
          
          
                            if (@move_uploaded_file($_FILES['image']['tmp_name'], $target))
                             {
                              $msg = "Image uploaded successfully";
                            }
                            else
                            {
                              $msg = "Failed to upload image";
                            }


                             $surname=$_POST['surname'];
                             $firstname=$_POST['firstname'];
                             $gender=$_POST['gender'];
                             $email=$_POST['email'];
                             $phone=$_POST['phone'];
                             $address=$_POST['address'];
                             $qualification=$_POST['qualification'];

                            if (!empty($surname) && !empty($firstname) && !empty($gender) && !empty($phone) && !empty($qualification) && !empty($address) && !empty($email))
                            {
                                $query=mysqli_query($conn,"INSERT INTO teacher(id,surname,firstname,gender,email,qualification,phone,address,regno,image,date) VALUES (null,'$surname','$firstname','$gender','$email','$qualification','$phone','$address','$regno','$direct',null)");

                                if ($query)
                                {
                                   echo '<script>alert("Teacher successfully registered");</script>';
   
                                }
                                else 
                                {
                                   echo mysqli_error($query);
                                }
                            }
                            else
                            {
                            echo '<script>alert("Fields cannot be blank");</script>';
                                
                            }
                            
                          }

                            
                            ?>

                        
                    


                        </form>
                    </div>
                </div>
                <!-- Add New Teacher Area End Here -->
               <?php
                    include 'footer.php'
               ?>
            </div>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Select 2 Js -->
    <script src="js/select2.min.js"></script>
    <!-- Date Picker Js -->
    <script src="js/datepicker.min.js"></script>
    <!-- Smoothscroll Js -->
    <script src="js/jquery.smoothscroll.min.html"></script>
    <!-- Scroll Up Js -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/add-teacher.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:39 GMT -->
</html>