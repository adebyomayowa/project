<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/student-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:36 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AKKHOR | Students Details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="css/all.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize js -->
    <script src="js/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
         <!-- Header Menu Area Start Here -->
     <?php
        include 'header.php'
     ?>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
      <?php include 'sidenav.php' ?>
            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Students</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Student Details</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Student Details Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>About Me</h3>
                            </div>
                           <div class="dropdown">
                                <a class="dropdown-toggle" href="#" role="button" 
                                data-toggle="dropdown" aria-expanded="false">...</a>
        
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="index.php"><i class="fas fa-times text-orange-red"></i>Close</a>
                                </div>
                            </div>
                        </div>

                        <?php
                        $id=$_GET['id'];
                        require 'conn.php';
                        $query= mysqli_query($conn,"SELECT * from student where id ='$id' ");

                        while ($row=mysqli_fetch_array($query)) 
                        {
                            $id=$row['id'];
                           $surname=$row['surname'];
                           $firstname=$row['firstname'];
                           $lastname=$row['lastname'];
                           $age=$row['age'];
                           $gender=$row['gender'];
                           $blood=$row['blood'];
                           $religion=$row['religion'];
                           $class=$row['class'];
                           $regno=$row['regno'];
                           $parentname=$row['parentname'];
                           $email=$row['email'];
                           $phone=$row['phone'];
                           $address=$row['address'];
                          $image =$row['myfile'];
                          $date =$row['date'];

                        }
                        ?>
                        <div class="single-info-details">
                            <div class="item-img">
                                <img src="<?php echo $image ?>" alt="student">
                            </div>
                            <div class="item-content">
                               
                                <div class="info-table table-responsive">
                                    <table class="table text-nowrap">
                                        <tbody>
                                            <tr>
                                                <td>Name:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $surname. " ".$firstname;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Gender:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $gender  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Parent Name:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $parentname?></td>
                                            </tr>
                                         
                                            <tr>
                                                <td>Registration Number</td>
                                                <td class="font-medium text-dark-medium"><?php echo $regno;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Religion:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $religion;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>E-mail:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $email;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Age:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $age;  ?></td>
                                            </tr> 
                                             <tr>
                                                <td>Blood:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $blood;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Admission Date:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $date;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Class:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $class;  ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Address:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $address;  ?></td>
                                            </tr>
                                            <tr>
                                                <td>Phone:</td>
                                                <td class="font-medium text-dark-medium"><?php echo $phone;  ?></td>
                                            </tr>
                                            <tr>
                                                <form action="student-details.php?id=<?php echo $id?>" method="post">
                                                <td><a role="button" class="btn btn-primary btn-lg" style="height:40px;font-weight:bold;font-size:15px;" href="editstudent.php?id=<?php echo $id?>"> Edit details</a></td>
                                                <td><input type="submit"  style="height:40px;font-weight:bold;font-size:15px;"   class="btn btn-warning btn-lg" name="delete" value="Delete"> </td>
                                                </form>
                                            </tr>
                                            <?php
                                            if (isset($_POST['delete']))
                                            {
                                                echo 'wawu';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Student Details Area End Here -->
                <?php
                 include 'footer.php'
                ?>
            </div>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Scroll Up Js -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/student-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:37 GMT -->
</html>