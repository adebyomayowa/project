<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/all-student.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:36 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AKKHOR | All Students</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="css/all.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Data Table CSS -->
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize js -->
    <script src="js/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
        <!-- Header Menu Area Start Here -->
        <?php include 'header.php' ?>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
            <?php include 'sidenav.php'?>
            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Students</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>All Students</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Student Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>All Students Data</h3>
                            </div>
                            <div class="dropdown">
                                <!-- <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                                    aria-expanded="false">...</a>

                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-times text-orange-red"></i>Close</a>
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                    <a class="dropdown-item" href="#"><i
                                            class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                </div> -->
                            </div>
                        </div>
                        <form class="mg-b-20" method="POST" action="all-student.php">
                          
                                <div class="col-4-xxxl col-xl-4 col-lg-4 col-12 form-group">
                                    <input type="text" name="find" placeholder="Search by Surname..." class="form-control">
                                </div>
                                <div class="col-1-xxxl col-xl-2 col-lg-3 col-12 form-group">
                                    <input type="submit" name="search" value="SEARCH" class="fw-btn-fill btn-gradient-yellow">
                                </div>
                            </div>
                        </form>
                        <?php

                          require 'conn.php';
                       if (isset($_POST['search']))
                       {
                        $find=$_POST['find'];
                          if (!empty($find))
                          {
                            
                            $queryfind=mysqli_query($conn,"SELECT * FROM student where surname  like '%$find%' ");
                            if (mysqli_num_rows($queryfind)>1)
                            {
                             echo ' <div class="table-responsive">
                             <table class="table  table-striped data-table text-nowrap">
                                 <thead>
                                     <tr>
                                         <th>Regno</th>
                                         <th>Photo</th>
                                         <th>Fullame</th>
                                         <th>Gender</th>
                                         <th>Class</th>
                                         <th>Religion</th>
                                         <th>Blood</th>
                                         <th>Age</th>
                                         <th>Parents</th>
                                         <th>Phone</th>
                                         <th>E-mail</th>
                                         <th></th>
                                     </tr>
                                 </thead>';  
                                 while ($row=mysqli_fetch_array($queryfind)) 
                                 {
                                     $id=$row['id'];
                                    $surname=$row['surname'];
                                    $firstname=$row['firstname'];
                                    $lastname=$row['lastname'];
                                    $age=$row['age'];
                                    $gender=$row['gender'];
                                    $blood=$row['blood'];
                                    $religion=$row['religion'];
                                    $class=$row['class'];
                                    $regno=$row['regno'];
                                    $parentname=$row['parentname'];
                                    $email=$row['email'];
                                    $phone=$row['phone'];
                                    $address=$row['address'];
                                   $image =$row['myfile'];
         
         
         
                                   echo '<tbody>
                                   <tr>
                                       <td>'.$regno.'</td>
                                       <td class="text-center"><img src="'.$image.'" class="img img-circle" alt="student" style="border-radius:50%;height:40px;"></td>
                                       <td>'.$surname.' '.$firstname.'</td>
                                       <td>'.$gender.'</td>
                                       <td>'.$class.'</td>
                                       <td>'.$religion.'</td>
                                       <td> '.$blood.' </td>
                                       <td>'.$age.'</td>
                                       <td>'.$parentname.'</td>
                                       <td>'.$phone.'</td>
                                       <td>'.$email.'</td>
                                       <td>
                                           <div class="dropdown">
                                               <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                                   aria-expanded="false">
                                                   <span class="flaticon-more-button-of-three-dots"></span>
                                               </a>
                                               <div class="dropdown-menu dropdown-menu-right">
                                                   
                                                   <a class="dropdown-item" href="student-details.php?id='.$id.'"><i
                                                           class="fas fa-cogs text-dark-pastel-green"></i>View Full details</a>
                                                  </div>
                                           </div>
                                       </td>';
                                
         
         
                                 } 
                                 
                                echo '   </tr>
                      
                                </tbody>
                            </table>
                        </div>';
                                }  
                            
                            else 
                            {
                                echo "No result found";
                            }
                          }
                          else
                          {
                             echo '<script>alert("Search field appear cannot empty");</script>'; 
                             echo '<script>window.location="all-student.php";</script>';
                          }
                       }
                       else
                       {
                        $query= mysqli_query($conn,"SELECT * from student");
                        echo ' <div class="table-responsive">
                        <table class="table  table-striped data-table text-nowrap">
                            <thead>
                                <tr>
                                    <th>Regno</th>
                                    <th>Photo</th>
                                    <th>Fullame</th>
                                    <th>Gender</th>
                                    <th>Class</th>
                                    <th>Religion</th>
                                    <th>Blood</th>
                                    <th>Age</th>
                                    <th>Parents</th>
                                    <th>Phone</th>
                                    <th>E-mail</th>
                                    <th></th>
                                </tr>
                            </thead>';
                        while ($row=mysqli_fetch_array($query)) 
                        {
                            $id=$row['id'];
                           $surname=$row['surname'];
                           $firstname=$row['firstname'];
                           $lastname=$row['lastname'];
                           $age=$row['age'];
                           $gender=$row['gender'];
                           $blood=$row['blood'];
                           $religion=$row['religion'];
                           $class=$row['class'];
                           $regno=$row['regno'];
                           $parentname=$row['parentname'];
                           $email=$row['email'];
                           $phone=$row['phone'];
                           $address=$row['address'];
                          $image =$row['myfile'];



                          echo '<tbody>
                          <tr>
                              <td>'.$regno.'</td>
                              <td class="text-center"><img src="'.$image.'" class="img img-circle" alt="student" style="border-radius:50%;height:40px;"></td>
                              <td>'.$surname.' '.$firstname.'</td>
                              <td>'.$gender.'</td>
                              <td>'.$class.'</td>
                              <td>'.$religion.'</td>
                              <td> '.$blood.' </td>
                              <td>'.$age.'</td>
                              <td>'.$parentname.'</td>
                              <td>'.$phone.'</td>
                              <td>'.$email.'</td>
                              <td>
                                  <div class="dropdown">
                                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                          aria-expanded="false">
                                          <span class="flaticon-more-button-of-three-dots"></span>
                                      </a>
                                      <div class="dropdown-menu dropdown-menu-right">
                                          
                                          <a class="dropdown-item" href="student-details.php?id='.$id.'"><i
                                                  class="fas fa-cogs text-dark-pastel-green"></i>View Full details</a>
                                         </div>
                                  </div>
                              </td>';
                       


                        } 
                        
                       echo '   </tr>
             
                       </tbody>
                   </table>
               </div>';
                       }
                        ?>
                       
                                
                    </>
                </div>
                <!-- Student Table Area End Here -->
               <?php 
                    include 'footer.php'
               ?>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Scroll Up Js -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Data Table Js -->
    <script src="js/jquery.dataTables.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/all-student.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2019 11:16:36 GMT -->
</html>